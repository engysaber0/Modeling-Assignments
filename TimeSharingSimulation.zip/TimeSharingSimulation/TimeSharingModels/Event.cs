namespace TimeSharingModels
{
    public enum EventType
    {
        Arrive,
        EndCpuRun,
        EndSimulation
    }

    public class Event
    {
        public EventType Type { get; set; }
        public double Time { get; set; }
        public Job Job { get; set; }
    }
}
