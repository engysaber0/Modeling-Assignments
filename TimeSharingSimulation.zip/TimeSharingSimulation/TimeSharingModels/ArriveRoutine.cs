namespace TimeSharingModels
{
    public static class ArriveRoutine
    {
        public static void Arrive(SimulationSystem sys, Job job)
        {
            sys.JobQueue.Enqueue(job);
        }
    }
}
