using System.Collections.Generic;

namespace TimeSharingModels
{
    public class Statistics
    {
        public double CurrentTime { get; set; } = 0.0;

        public double QueueArea { get; set; } = 0.0;

        public double CpuBusyTime { get; set; } = 0.0;

        public int JobsCompleted { get; set; } = 0;
        public double TotalResponseTime { get; set; } = 0.0;

        public List<Job> CompletedJobs { get; set; } = new List<Job>();

        public double AverageResponseTime => JobsCompleted == 0 ? 0.0 : TotalResponseTime / JobsCompleted;

        public double AverageQueueLength => CurrentTime <= 0 ? 0.0 : QueueArea / CurrentTime;
        public double Utilization => CurrentTime <= 0 ? 0.0 : CpuBusyTime / CurrentTime;
    }
}
