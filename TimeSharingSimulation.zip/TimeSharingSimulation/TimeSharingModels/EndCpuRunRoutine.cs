namespace TimeSharingModels
{
    public static class EndCpuRunRoutine
    {
        public static void EndCpuRun(SimulationSystem sys)
        {
            var job = sys.CPU.CurrentJob;
            double now = sys.Stats.CurrentTime;

            if (job == null) return;

            double servedAmount;

            if (sys.Policy == SchedulingPolicy.RoundRobin)
            {
                servedAmount = System.Math.Min(sys.Quantum, job.RemainingTime);
            }
            else
            {
                servedAmount = job.RemainingTime;
            }

            job.RemainingTime -= servedAmount;

            sys.Stats.CpuBusyTime += servedAmount;

            if (job.IsFinished)
            {
                job.EndServiceTime = now;
                sys.Stats.JobsCompleted++;
                sys.Stats.TotalResponseTime += job.ResponseTime;
                sys.Stats.CompletedJobs.Add(job);
            }
            else
            {
                sys.JobQueue.Enqueue(job);
            }

            sys.CPU.IsBusy = false;
            sys.CPU.CurrentJob = null;
            sys.CPU.CurrentJobEndTime = double.PositiveInfinity;
        }
    }
}
