namespace TimeSharingModels
{
    public class CpuState
    {
        public bool IsBusy { get; set; } = false;
        public Job CurrentJob { get; set; } = null;
        public double CurrentJobEndTime { get; set; } = double.PositiveInfinity;
    }
}
