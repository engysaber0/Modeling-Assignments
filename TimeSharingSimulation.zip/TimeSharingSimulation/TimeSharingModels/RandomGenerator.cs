using System;

namespace TimeSharingModels
{
    public static class RandomGenerator
    {
        private static readonly Random rnd = new Random();

        public static double Exponential(double mean)
        {
            return -mean * Math.Log(rnd.NextDouble());
        }
    }
}
