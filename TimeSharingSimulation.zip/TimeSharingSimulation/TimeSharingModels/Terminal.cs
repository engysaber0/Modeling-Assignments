namespace TimeSharingModels
{
    public class Terminal
    {
        public int Id { get; set; }
        public double NextArrivalTime { get; set; }
        public double LastThinking { get; set; }
    }
}
