using System;
using System.Collections.Generic;

namespace TimeSharingModels
{
    public enum SchedulingPolicy
    {
        RoundRobin,
        ShortestJobFirst
    }

    public enum StopCondition
    {
        NumberOfJobs,
        CpuRuntime
    }

    public class SimulationSystem
    {
        public int NumberOfTerminals { get; set; } = 10;
        public double Quantum { get; set; } = 0.1;
        public double SwapTime { get; set; } = 0.015;
        public SchedulingPolicy Policy { get; set; } = SchedulingPolicy.RoundRobin;

        public StopCondition StopBy { get; set; } = StopCondition.NumberOfJobs;
        public int TargetJobs { get; set; } = 1000;
        public double MaxCpuTime { get; set; } = 1000.0;

        public double ThinkMean { get; set; } = 25.0;
        public double ServiceMean { get; set; } = 0.8;

        public List<Terminal> Terminals { get; set; } = new List<Terminal>();
        public Queue<Job> JobQueue { get; set; } = new Queue<Job>();
        public CpuState CPU { get; set; } = new CpuState();
        public Statistics Stats { get; set; } = new Statistics();

        public Func<double> ThinkTimeGen { get; set; }
        public Func<double> ServiceTimeGen { get; set; }

        public int NextJobId { get; set; } = 1;

        public SimulationSystem()
        {
            ThinkTimeGen = () => RandomGenerator.Exponential(ThinkMean);
            ServiceTimeGen = () => RandomGenerator.Exponential(ServiceMean);
        }

        public void InitializeTerminals()
        {
            Terminals = new List<Terminal>();
            for (int i = 0; i < NumberOfTerminals; i++)
            {
                double t = ThinkTimeGen();
                Terminals.Add(new Terminal()
                {
                    Id = i + 1,
                    NextArrivalTime = t,
                    LastThinking = t
                });
            }
        }

        public void ResetStateForRun()
        {
            JobQueue = new Queue<Job>();
            CPU = new CpuState();
            Stats = new Statistics();
            NextJobId = 1;
        }
    }
}
