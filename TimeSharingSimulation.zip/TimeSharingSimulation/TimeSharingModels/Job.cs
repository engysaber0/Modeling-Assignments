using System;

namespace TimeSharingModels
{
    public class Job
    {
        public int Id { get; set; }
        public double ArrivalTime { get; set; }
        public double ServiceTime { get; set; }
        public double RemainingTime { get; set; }
        public double StartServiceTime { get; set; } = double.NaN;
        public double EndServiceTime { get; set; } = double.NaN;

        public double ResponseTime => EndServiceTime - ArrivalTime;

        public bool IsFinished => RemainingTime <= 1e-12;
    }
}
