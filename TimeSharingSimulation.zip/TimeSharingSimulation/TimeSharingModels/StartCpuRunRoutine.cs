using System;
using System.Linq;
namespace TimeSharingModels
{
    public static class StartCpuRunRoutine
    {
        public static double StartCpu(SimulationSystem sys)
        {
            if (sys.CPU.IsBusy) return sys.CPU.CurrentJobEndTime;
            if (sys.JobQueue.Count == 0) return double.PositiveInfinity;

            Job jobToRun = null;
            double now = sys.Stats.CurrentTime;

            if (sys.Policy == SchedulingPolicy.RoundRobin)
            {
                jobToRun = sys.JobQueue.Dequeue();
                double timeslice = Math.Min(sys.Quantum, jobToRun.RemainingTime);
                double endTime = now + timeslice + sys.SwapTime;

                if (double.IsNaN(jobToRun.StartServiceTime)) jobToRun.StartServiceTime = now;

                sys.CPU.IsBusy = true;
                sys.CPU.CurrentJob = jobToRun;
                sys.CPU.CurrentJobEndTime = endTime;

                return endTime;
            }
            else
            {
                var list = sys.JobQueue.ToList();
                sys.JobQueue.Clear();

                int idx = 0;
                double minRem = double.MaxValue;
                for (int i = 0; i < list.Count; i++)
                {
                    if (list[i].RemainingTime < minRem)
                    {
                        minRem = list[i].RemainingTime;
                        idx = i;
                    }
                }

                jobToRun = list[idx];
                for (int i = 0; i < list.Count; i++)
                {
                    if (i == idx) continue;
                    sys.JobQueue.Enqueue(list[i]);
                }

                double endTime = now + jobToRun.RemainingTime + sys.SwapTime;
                if (double.IsNaN(jobToRun.StartServiceTime)) jobToRun.StartServiceTime = now;

                sys.CPU.IsBusy = true;
                sys.CPU.CurrentJob = jobToRun;
                sys.CPU.CurrentJobEndTime = endTime;

                return endTime;
            }
        }
    }
}
