﻿using System;
using System.Linq;
using System.Windows.Forms;
using TimeSharingModels;

namespace TimeSharingSimulation
{
    public partial class Form1 : Form
    {
        private SimulationSystem sys;

        public Form1()
        {
            InitializeComponent();
            InitializeExtra();
        }

        private void InitializeExtra()
        {
            cmbPolicy.Items.Clear();
            cmbPolicy.Items.Add(SchedulingPolicy.RoundRobin.ToString());
            cmbPolicy.Items.Add(SchedulingPolicy.ShortestJobFirst.ToString());
            cmbPolicy.SelectedIndex = 0;

            rdoStopJobs.Checked = true;

            dgvJobs.AutoGenerateColumns = false;
            dgvJobs.Columns.Clear();
            dgvJobs.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Id",
                DataPropertyName = "Id",
                Width = 60
            });
            dgvJobs.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Arrival",
                DataPropertyName = "ArrivalTime",
                Width = 80,
                DefaultCellStyle = { Format = "0.000" }
            });
            dgvJobs.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Start",
                DataPropertyName = "StartServiceTime",
                Width = 80,
                DefaultCellStyle = { Format = "0.000" }
            });
            dgvJobs.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "End",
                DataPropertyName = "EndServiceTime",
                Width = 80,
                DefaultCellStyle = { Format = "0.000" }
            });
            dgvJobs.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Response",
                DataPropertyName = "ResponseTime",
                Width = 90,
                DefaultCellStyle = { Format = "0.000" }
            });
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            sys = new SimulationSystem();
            sys.NumberOfTerminals = (int)numTerminals.Value;
            sys.ThinkMean = (double)numThinkMean.Value;
            sys.ServiceMean = (double)numServiceMean.Value;
            sys.Quantum = (double)numQuantum.Value;
            sys.SwapTime = (double)numSwap.Value;

            sys.Policy = (SchedulingPolicy)Enum.Parse(typeof(SchedulingPolicy), cmbPolicy.SelectedItem.ToString());

            if (rdoStopJobs.Checked)
            {
                sys.StopBy = StopCondition.NumberOfJobs;
                sys.TargetJobs = (int)numJobs.Value;
            }
            else
            {
                sys.StopBy = StopCondition.CpuRuntime;
                sys.MaxCpuTime = (double)numCpuTime.Value;
            }

            sys.ThinkTimeGen = () => RandomGenerator.Exponential(sys.ThinkMean);
            sys.ServiceTimeGen = () => RandomGenerator.Exponential(sys.ServiceMean);

            RunSimulation();

            txtAvgResponse.Text = sys.Stats.AverageResponseTime.ToString("0.000");
            txtAvgQueue.Text = sys.Stats.AverageQueueLength.ToString("0.000");
            txtUtil.Text = (sys.Stats.Utilization * 100.0).ToString("0.000") + " %";

            dgvJobs.DataSource = sys.Stats.CompletedJobs.Select(j => new
            {
                j.Id,
                j.ArrivalTime,
                j.StartServiceTime,
                j.EndServiceTime,
                ResponseTime = j.ResponseTime
            }).ToList();
        }

        private void RunSimulation()
        {
            sys.ResetStateForRun();
            sys.InitializeTerminals();

            double now = 0.0;
            sys.Stats.CurrentTime = 0.0;
            double nextCpuFinish = double.PositiveInfinity;

            while (true)
            {
                double nextArrival = sys.Terminals.Min(t => t.NextArrivalTime);
                nextCpuFinish = sys.CPU.IsBusy ? sys.CPU.CurrentJobEndTime : double.PositiveInfinity;

                double nextEvent = Math.Min(nextArrival, nextCpuFinish);

                if (double.IsInfinity(nextEvent)) break;

                double delta = nextEvent - sys.Stats.CurrentTime;
                if (delta < 0) delta = 0;
                sys.Stats.QueueArea += sys.JobQueue.Count * delta;
                sys.Stats.CurrentTime = nextEvent;

                foreach (var term in sys.Terminals.Where(t => Math.Abs(t.NextArrivalTime - nextEvent) < 1e-9).ToList())
                {
                    var job = new Job()
                    {
                        Id = sys.NextJobId++,
                        ArrivalTime = nextEvent,
                        ServiceTime = sys.ServiceTimeGen(),
                        RemainingTime = 0.0
                    };
                    job.RemainingTime = job.ServiceTime;

                    ArriveRoutine.Arrive(sys, job);
                    double nextThink = sys.ThinkTimeGen();
                    term.LastThinking = nextThink;
                    term.NextArrivalTime = nextEvent + nextThink;
                }

                if (sys.CPU.IsBusy && Math.Abs(sys.CPU.CurrentJobEndTime - nextEvent) < 1e-9)
                {
                    EndCpuRunRoutine.EndCpuRun(sys);
                }

                if (!sys.CPU.IsBusy && sys.JobQueue.Count > 0)
                {
                    double scheduledEnd = StartCpuRunRoutine.StartCpu(sys);
                }

                if (sys.StopBy == StopCondition.NumberOfJobs)
                {
                    if (sys.Stats.JobsCompleted >= sys.TargetJobs) break;
                }
                else
                {
                    if (sys.Stats.CurrentTime >= sys.MaxCpuTime) break;
                }
            }

        }
    }
}
