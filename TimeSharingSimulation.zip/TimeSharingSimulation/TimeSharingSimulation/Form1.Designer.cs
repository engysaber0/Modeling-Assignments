﻿namespace TimeSharingSimulation
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel header;
        private System.Windows.Forms.Label lblHeader;

        private System.Windows.Forms.NumericUpDown numTerminals;
        private System.Windows.Forms.NumericUpDown numThinkMean;
        private System.Windows.Forms.NumericUpDown numServiceMean;
        private System.Windows.Forms.NumericUpDown numQuantum;
        private System.Windows.Forms.NumericUpDown numSwap;
        private System.Windows.Forms.NumericUpDown numJobs;
        private System.Windows.Forms.NumericUpDown numCpuTime;

        private System.Windows.Forms.Button btnRun;

        private System.Windows.Forms.ComboBox cmbPolicy;

        private System.Windows.Forms.RadioButton rdoStopJobs;
        private System.Windows.Forms.RadioButton rdoStopCpu;

        private System.Windows.Forms.TextBox txtAvgResponse;
        private System.Windows.Forms.TextBox txtAvgQueue;
        private System.Windows.Forms.TextBox txtUtil;

        private System.Windows.Forms.DataGridView dgvJobs;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.BackColor = System.Drawing.Color.FromArgb(245, 245, 245);
            this.Font = new System.Drawing.Font("Segoe UI", 10F);

            header = new System.Windows.Forms.Panel();
            header.Dock = System.Windows.Forms.DockStyle.Top;
            header.Height = 70;
            header.BackColor = System.Drawing.Color.FromArgb(30, 136, 229);

            lblHeader = new System.Windows.Forms.Label();
            lblHeader.Text = "TIME SHARED CPU SIMULATION";
            lblHeader.ForeColor = System.Drawing.Color.White;
            lblHeader.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            lblHeader.AutoSize = false;
            lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            lblHeader.Dock = System.Windows.Forms.DockStyle.Fill;

            header.Controls.Add(lblHeader);
            this.Controls.Add(header);

            var inputPanel = new System.Windows.Forms.Panel();
            inputPanel.Width = 430;
            inputPanel.Height = 520;
            inputPanel.Left = 20;
            inputPanel.Top = 90;
            inputPanel.BackColor = System.Drawing.Color.White;
            inputPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            var lblInputs = new System.Windows.Forms.Label();
            lblInputs.Text = "INPUT PARAMETERS";
            lblInputs.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            lblInputs.ForeColor = System.Drawing.Color.FromArgb(33, 33, 33);
            lblInputs.Top = 10;
            lblInputs.Left = 15;
            lblInputs.AutoSize = true;

            inputPanel.Controls.Add(lblInputs);

            int y = 60;
            System.Windows.Forms.Label MakeLabel(string text)
            {
                var l = new System.Windows.Forms.Label();
                l.Text = text;
                l.Left = 12;
                l.Top = y;
                l.AutoSize = true;
                l.Font = new System.Drawing.Font("Segoe UI", 10F);
                y += 36;
                inputPanel.Controls.Add(l);
                return l;
            }

            System.Windows.Forms.NumericUpDown MakeNumeric(decimal val, decimal min, decimal max, int dec = 0)
            {
                var n = new System.Windows.Forms.NumericUpDown();
                n.Left = 240;
                n.Top = y - 36;
                n.Width = 140;
                n.DecimalPlaces = dec;
                n.Minimum = min;
                n.Maximum = max;
                n.Value = val;
                inputPanel.Controls.Add(n);
                return n;
            }

            int numLeftOffset = 240;

            MakeLabel("Number of Terminals:");
            numTerminals = MakeNumeric(10, 1, 500);

            MakeLabel("Mean Thinking Time (sec) [Exp]:");
            numThinkMean = MakeNumeric(25, 0, 9999, 1);

            MakeLabel("Mean Service Time (sec) [Exp]:");
            numServiceMean = MakeNumeric(0.8M, 0.0M, 9999, 3);

            MakeLabel("Scheduling Policy:");
            cmbPolicy = new System.Windows.Forms.ComboBox();
            cmbPolicy.Left = numLeftOffset;
            cmbPolicy.Top = y;
            cmbPolicy.Width = 140;
            cmbPolicy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            inputPanel.Controls.Add(cmbPolicy);
            y += 36;

            MakeLabel("Quantum (sec):");
            numQuantum = MakeNumeric(0.1M, 0.01M, 100, 3);

            MakeLabel("Swap Time (sec):");
            numSwap = MakeNumeric(0.015M, 0.0M, 10, 3);

            MakeLabel("Stopping Condition:");

            rdoStopJobs = new System.Windows.Forms.RadioButton();
            rdoStopJobs.Left = numLeftOffset;
            rdoStopJobs.Top = y - 36;
            rdoStopJobs.Text = "By # jobs";
            rdoStopJobs.AutoSize = true;
            rdoStopJobs.Font = new System.Drawing.Font("Segoe UI", 10F);
            inputPanel.Controls.Add(rdoStopJobs);

            numJobs = MakeNumeric(1000, 1, 1000000);
            numJobs.Left = numLeftOffset + 80;
            numJobs.Top = y - 36;
            numJobs.Width = 100;

            y += 36;

            rdoStopCpu = new System.Windows.Forms.RadioButton();
            rdoStopCpu.Left = numLeftOffset;
            rdoStopCpu.Top = y - 36;
            rdoStopCpu.Text = "By CPU runtime (sec)";
            rdoStopCpu.AutoSize = true;
            rdoStopCpu.Font = new System.Drawing.Font("Segoe UI", 10F);
            inputPanel.Controls.Add(rdoStopCpu);

            numCpuTime = MakeNumeric(1000, 1, 1_000_000, 1);
            numCpuTime.Left = numLeftOffset + 80;
            numCpuTime.Top = y ;
            numCpuTime.Width = 100;

            y += 46;

            btnRun = new System.Windows.Forms.Button();
            btnRun.Text = "RUN SIMULATION";
            btnRun.Width = 200;
            btnRun.Height = 44;
            btnRun.Left = 110;
            btnRun.Top = y;
            btnRun.BackColor = System.Drawing.Color.FromArgb(56, 142, 60);
            btnRun.ForeColor = System.Drawing.Color.White;
            btnRun.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnRun.FlatAppearance.BorderSize = 0;
            btnRun.Click += new System.EventHandler(this.btnRun_Click);
            inputPanel.Controls.Add(btnRun);

            this.Controls.Add(inputPanel);

            int outputLeft = 460;

            var outputPanel = new System.Windows.Forms.Panel();
            outputPanel.Width = 420;
            outputPanel.Height = 200;
            outputPanel.Left = outputLeft;
            outputPanel.Top = 90;
            outputPanel.BackColor = System.Drawing.Color.White;
            outputPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            var lblOutputs = new System.Windows.Forms.Label();
            lblOutputs.Text = "SIMULATION OUTPUT";
            lblOutputs.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            lblOutputs.Left = 12;
            lblOutputs.Top = 12;
            lblOutputs.AutoSize = true;
            outputPanel.Controls.Add(lblOutputs);

            int oy = 52;
            void AddOutputRow(string labelText, out System.Windows.Forms.TextBox box)
            {
                var l = new System.Windows.Forms.Label();
                l.Text = labelText;
                l.Left = 12;
                l.Top = oy;
                l.AutoSize = true;
                outputPanel.Controls.Add(l);

                box = new System.Windows.Forms.TextBox();
                box.Left = 220;
                box.Top = oy - 4;
                box.Width = 160;
                box.ReadOnly = true;
                outputPanel.Controls.Add(box);

                oy += 40;
            }

            AddOutputRow("Average response time (sec):", out txtAvgResponse);
            AddOutputRow("Average queue length:", out txtAvgQueue);
            AddOutputRow("CPU Utilization:", out txtUtil);

            this.Controls.Add(outputPanel);

            dgvJobs = new System.Windows.Forms.DataGridView();
            dgvJobs.Left = outputLeft;
            dgvJobs.Top = 300;
            dgvJobs.Width = 420;
            dgvJobs.Height = 310;
            dgvJobs.BackgroundColor = System.Drawing.Color.White;
            dgvJobs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            dgvJobs.ReadOnly = true;
            dgvJobs.AllowUserToAddRows = false;
            dgvJobs.AllowUserToDeleteRows = false;

            this.Controls.Add(dgvJobs);

            this.ClientSize = new System.Drawing.Size(900, 640);
            this.Text = "Time Shared CPU Simulation - RR & SJF (Exponential)";
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        }
    }
}